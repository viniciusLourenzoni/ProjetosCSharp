﻿namespace Course
{
    class Estudante
    {
        public string Nome { get; set; }
        public int Idade { get; set; }
        public DateTime DataNascimento { get; set; }
    }
}