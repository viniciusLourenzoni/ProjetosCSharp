﻿using System;

namespace Course
{
    class Program
    {
        static void Main(string[] args)
        {
            Estudante estudante = new Estudante();

            Console.Write("Digite seu nome: ");
            estudante.Nome = Console.ReadLine();

            Console.Write("Digite sua Idade: ");
            estudante.Idade = int.Parse(Console.ReadLine());
          
        }
    }
}