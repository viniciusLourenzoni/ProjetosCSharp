﻿using System;

class Program
{
    static void Main(string[] args)
    {
        while (true)
        {
            Console.WriteLine("Digite o tamanho da cifra e o número de mensagens cifradas separados por um espaço:");
            string entrada = Console.ReadLine();

            // Verifica se chegou ao final da entrada
            if (string.IsNullOrEmpty(entrada))
            {
                break;
            }

            string[] tokens = entrada.Split();
            int tamanhoCifra = int.Parse(tokens[0]);
            int numeroMensagens = int.Parse(tokens[1]);

            // Cria o mapa de substituição
            char[] mapaSubstituicao = new char[128];
            Console.WriteLine("Digite a cifra:");
            string cifra = Console.ReadLine();
            Console.WriteLine("Digite a correspondência de substituição:");
            string correspondencia = Console.ReadLine();
            for (int i = 0; i < tamanhoCifra; i++)
            {
                char letraCifrada = cifra[i];
                char letraDecifrada = correspondencia[i];
                mapaSubstituicao[letraCifrada] = letraDecifrada;
            }

            // Decifra as mensagens cifradas
            Console.WriteLine("Digite as mensagens cifradas:");
            for (int i = 0; i < numeroMensagens; i++)
            {
                string mensagemCifrada = Console.ReadLine();
                string mensagemDecifrada = "";
                for (int j = 0; j < mensagemCifrada.Length; j++)
                {
                    char caractereCifrado = mensagemCifrada[j];
                    char caractereDecifrado = mapaSubstituicao[caractereCifrado];
                    if (caractereDecifrado == 0)
                    {
                        caractereDecifrado = char.ToLower(caractereCifrado);
                    }
                    else if (char.IsUpper(caractereCifrado))
                    {
                        caractereDecifrado = char.ToUpper(caractereDecifrado);
                    }
                    mensagemDecifrada += caractereDecifrado;
                }
                Console.WriteLine(mensagemDecifrada);
            }

            Console.WriteLine();
        }
    }
}
