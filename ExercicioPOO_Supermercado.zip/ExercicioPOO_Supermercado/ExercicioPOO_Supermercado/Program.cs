﻿using ExercicioPOO_Supermercado;
using System;
using System.Globalization;

namespace ExercicioSupermercado
{
    class Programa
    {
        static void Main(string[] args)
        {

            string[] vet = new string[] { "Maria", "Alex", "Bob" };

            foreach (string nome in vet)
            {
                Console.WriteLine(nome);
            }
            
        }

    }
}