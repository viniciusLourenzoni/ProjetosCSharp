﻿using System;

namespace ExercicioPOO_Supermercado
{
    internal class Produto
    {
        public string Nome { get; set; }
        public double Preco { get; set;}
        public int Quantidade { get; set;}

        public Produto(string nome, double preco, int quantidade)
        {
            this.Nome = nome;
            this.Preco = preco;
            this.Quantidade = quantidade;
        }

        public Produto(string nome, double preco)
        {
            this.Nome = nome;
            this.Preco = preco;
        }

        public override string ToString()
        {
            return "Nome do Produto: " + Nome +"\n"
                + "Preco: " + Preco + "\n"
                + "Quantidade: " + Quantidade;
        }
    }

}
