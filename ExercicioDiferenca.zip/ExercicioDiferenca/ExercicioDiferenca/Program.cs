﻿using System;
class Program
{
    static void Main(string[] args)
    {

        int a, b, c, d, diferenca;

        Console.WriteLine("Este programa aplica o calculo da diferença entre 4 números diferentes.");

        Console.WriteLine("Insira o primeiro número: ");
        a = int.Parse(Console.ReadLine());

        Console.WriteLine("Insira o segundo número: ");
        b = int.Parse(Console.ReadLine());

        Console.WriteLine("Insira o terceiro número: ");
        c = int.Parse(Console.ReadLine());

        Console.WriteLine("Insira o quarto número: ");
        d = int.Parse(Console.ReadLine());

        diferenca = (a * b - c * d);

        Console.WriteLine("O valor da diferenca é: " + diferenca);

    }
}
