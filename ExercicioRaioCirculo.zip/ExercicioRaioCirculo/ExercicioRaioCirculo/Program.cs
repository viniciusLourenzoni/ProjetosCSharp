﻿using System;
class Program
{
    static void Main(string[] args)
    {

        double raio;
        double pi = 3.14159;
        double area;


        Console.WriteLine("Informe o valor do raio do Círculo");
        raio = double.Parse(Console.ReadLine());

        area = pi*(raio*raio);

        Console.WriteLine("O valor da área desse circulo é: " + area);

    }
}