﻿using System;
using System.Globalization;

class Program
{
    static void Main(string[] args)
    {

        int numeroFuncionario;
        int horasTrabalhadas;
        double valorHora;
        double salario;

        Console.WriteLine("Informe o número do Funcionário: ");
        numeroFuncionario = int.Parse(Console.ReadLine());

        Console.WriteLine("Informe o número de horas trabalhadas desse funcionário: ");
        horasTrabalhadas = int.Parse(Console.ReadLine()); 

        Console.WriteLine("Informe o valor que este funcionário ganha por hora: ");
        valorHora = double.Parse(Console.ReadLine());

        salario = horasTrabalhadas * valorHora;

        Console.WriteLine("Número do Funcionário: " + numeroFuncionario);
        Console.WriteLine("Salário do Funcionário: " + salario.ToString("F2", CultureInfo.InvariantCulture));

    }
}