﻿using System;

namespace Grenal
{
    class Program
    {
        static void Main(string[] args)
        {

            int golsInter, golsGremio, vitoriaGremio, vitoriaInter, novoGrenal, numeroEmpates, numeroGrenais;

            vitoriaGremio = 0;
            vitoriaInter = 0;
            numeroEmpates = 0;
            numeroGrenais = 0;

            Console.WriteLine("Gols Inter: ");
            golsInter = int.Parse(Console.ReadLine());

            Console.WriteLine("Gols Grêmio: ");
            golsGremio = int.Parse(Console.ReadLine());

            Console.WriteLine("Novo grenal (1-sim 2-nao)");
            novoGrenal = int.Parse(Console.ReadLine());

            numeroGrenais++;

            if (golsInter > golsGremio)
            {
                vitoriaInter++;
            }

            if (golsGremio > golsInter)
            {
                vitoriaGremio++;
            }

            if (golsGremio == golsInter)
            {
                numeroEmpates++;
            }

            while (novoGrenal != 2)
            {
                if (novoGrenal == 1)
                {
                    numeroGrenais++;
                }

                Console.WriteLine("Gols Inter: ");
                golsInter = int.Parse(Console.ReadLine());

                Console.WriteLine("Gols Grêmio: ");
                golsGremio = int.Parse(Console.ReadLine());

                Console.WriteLine("Novo grenal (1-sim 2-nao)");
                novoGrenal = int.Parse(Console.ReadLine());

                if (golsInter > golsGremio)
                {
                    vitoriaInter++;
                }

                if (golsGremio > golsInter)
                {
                    vitoriaGremio++;
                }

                if (golsGremio == golsInter)
                {
                    numeroEmpates++;

                }

            }

            Console.WriteLine("Total de Grenais: " + numeroGrenais + "\n");
            Console.WriteLine("Numero de vitórias Inter: " + vitoriaInter + "\n");
            Console.WriteLine("Numero de vitórias Gremio: " + vitoriaGremio + "\n");
            Console.WriteLine("Número de Empates: " + numeroEmpates + "\n");

            if (vitoriaInter > vitoriaGremio)
            {
                Console.WriteLine("Inter venceu mais!");
            }

            if (vitoriaGremio > vitoriaInter)
            {
                Console.WriteLine("Gremio venceu mais!");
            }

            if (vitoriaGremio == vitoriaInter)
            {
                Console.WriteLine("Não houve vencedor!");
            }
        }

    }
}