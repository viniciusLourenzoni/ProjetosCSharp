﻿using System;
using System.Globalization;

namespace InvestimentoMensal
{
    class Program
    {
        static void Main(string[] args)
        {

            double valorFixo;
            double rentabilidade = 0.008;
            int meses;
            double valorFinal;
            double valorRendidoMes;
            int testeFodase = 5000;

            Console.WriteLine("Informe o valor fixo que quer guardar por mês: ");
            valorFixo = double.Parse(Console.ReadLine());

            Console.WriteLine("Informe por quantos meses deseja render este dinheiro: ");
            meses = int.Parse(Console.ReadLine());


            valorFinal = 0.0;
            valorRendidoMes = 0.0;

            for (int i = 0; i < meses; i++)
            {
                valorRendidoMes = valorFixo * rentabilidade;
                valorFinal = valorFixo + valorRendidoMes;

                valorFixo = valorFinal;
                valorFixo = valorFixo + testeFodase;
            }

            Console.WriteLine("Valor Total Adquirido em " + meses + " meses é:");
            Console.WriteLine("R$ " + valorFinal.ToString("F2", CultureInfo.InvariantCulture));
        }
    }
}